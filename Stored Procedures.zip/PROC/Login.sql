-------------------------------Select Login-------------------
------------------------------------------------------------------------
CREATE PROCEDURE Login
    @Username VARCHAR(50)
AS
BEGIN
    SELECT * FROM [Login] WHERE User_Name = @Username;
END

----------------------------------Delete Login-------------------
--------------------------------------------------------------------------
CREATE PROCEDURE Delete_Login 
    @Username VARCHAR(50)
AS
BEGIN TRY
    DELETE FROM [Login] 
    WHERE User_Name = @Username;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
---------------------------------------------------------------------------=
-------------------------------Insert Login------------------------
CREATE PROCEDURE Insrt_Login 
    @User_Name VARCHAR(50),  
    @St_Id INT,
    @Password INT
AS  
BEGIN TRY
    INSERT INTO [Login] (User_Name, St_Id, Password)
    VALUES (@User_Name, @St_Id, @Password);
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

--------------------------------------------------------------------------------
-------------------------------Update Login----------------------------
CREATE PROCEDURE Update_Login  
    @User_Name VARCHAR(50),  
    @St_Id INT,
    @Password INT
AS  
BEGIN TRY  
    UPDATE [Login]
    SET User_Name = @User_Name,  
        St_Id = @St_Id,
        Password = @Password
    WHERE User_Name = @User_Name;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;
