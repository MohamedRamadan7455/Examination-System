-- Procedure to retrieve all certificates
CREATE PROCEDURE select_Certificate(@Cert_Ver INT)
AS
	BEGIN
		IF @Cert_Ver = 0
			BEGiN 
				SELECT * FROM Courses
			END
		ELSE
		SELECT *
		FROM	Certificates
		WHERE Cert_verification = @Cert_Ver
	END

------------------------------------------------------------

-- Procedure to add a new certificate
CREATE OR ALTER PROCEDURE ADD_CERT
    @ST_ID INT,
    @C_NAME VARCHAR(75),
    @DURATION INT,
    @PLATFORM VARCHAR(75)
AS 
BEGIN
    BEGIN TRY
        INSERT INTO Certificates 
            VALUES (@ST_ID, @C_NAME, @DURATION, @PLATFORM)
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END

-------------------------------------------------------

-- Procedure to update an existing certificate
CREATE OR ALTER PROCEDURE Update_Certificate
    @CERT_VER INT,
    @ST_ID INT,
    @C_NAME VARCHAR(75),
    @DURATION INT,
    @PLATFORM VARCHAR(75)
AS
BEGIN
    BEGIN TRY
        UPDATE Certificates
        SET 
            St_Id = @ST_ID,
            Cert_name = @C_NAME,
            Duration = @DURATION,
            Platform = @PLATFORM
        WHERE Cert_verification = @CERT_VER
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END

------------------------------------------------------------------------------

-- Procedure to delete a certificate by verification
CREATE OR ALTER PROCEDURE DELETE_CERT
    @CERT_VER INT
AS
BEGIN 
    BEGIN TRY
        DELETE FROM Certificates WHERE Cert_verification = @CERT_VER
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
