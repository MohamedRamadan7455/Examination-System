------------------------------------Student_Intake SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE Select_StIntake
    @St_Id INT
AS
BEGIN
    IF @St_Id = 0
    BEGIN
        SELECT * FROM Student_Intake;
    END
    ELSE
    BEGIN
        SELECT * FROM Student_Intake WHERE St_Id = @St_Id;
    END
END

----------------------------------------------------------------------------------------
------------------------------------Student_Intake Delete Proc-----------------------------
CREATE PROCEDURE Delete_StIntake
    @St_Id INT
AS
BEGIN TRY
    DELETE FROM Student_Intake
    WHERE St_Id = @St_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Student_Intake Insert Proc------------------------------
CREATE PROCEDURE insert_StIntake
    @St_Id int,  
    @Intake_Num INT
AS  
BEGIN TRY
    INSERT INTO Student_Intake(St_Id, Intake_Num)
    VALUES (@St_Id, @Intake_Num);
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
----------------------------------------------------------------------------------------
------------------------------------Student_Intake UPDATE Proc------------------------------
CREATE PROCEDURE Update_InsIntake
    @St_Id int,  
    @Intake_Num INT
AS  
BEGIN TRY  
    UPDATE Student_Intake
    SET St_Id = @St_Id,  
        Intake_Num = @Intake_Num              			   
    WHERE St_Id = @St_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
