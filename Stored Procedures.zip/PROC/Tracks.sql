------------------------------------Track SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE select_Track(@Track_Id INT)
AS
	BEGIN
		IF @Track_Id = 0
			BEGiN 
				SELECT * FROM Tracks
			END
		ELSE
		SELECT *
		FROM	Tracks
		WHERE Track_Id = @Track_Id
	END
----------------------------------------------------------------------------------------
------------------------------------Track UPDATE Proc------------------------------
CREATE PROCEDURE Update_Track
(
    @Track_Id INT,  
    @Track_Name VARCHAR(50),  
    @Ins_Id INT
)                               
AS
BEGIN TRY  
    UPDATE Tracks
    SET    
	   
        Track_Name = @Track_Name,
        Ins_Id = @Ins_Id
    WHERE Track_Id =@Track_Id ;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
--------------------------------Insert Tracks-------------------------------------------
CREATE PROCEDURE Insert_Track
(
    @Track_Name VARCHAR(50),  
    @Ins_Id INT
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Tracks
        (
        
            Track_Name,  
            Ins_Id
        )   
        VALUES
        (
      
            @Track_Name,  
            @Ins_Id
        );   
    END TRY
	
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;
    

----------------------------------------------------------------------------------------
------------------------------------track Delete Proc-----------------------------
CREATE PROCEDURE Delete_Track
(
   @Track_Id INT
)
AS
BEGIN TRY
    DELETE FROM Tracks
    WHERE Track_Id = @Track_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

