-- Retrieve Students Procedure
CREATE OR ALTER PROC Select_Student(@St_ID INT)
AS 
BEGIN
    SELECT * FROM Students
	Where St_Id=@St_ID
END
-------------------------------------------------------------------------------------------------------
-- Add Student Procedure
CREATE OR ALTER PROC Insert_Student
    @S_FNAME VARCHAR(50),
    @S_LNAME VARCHAR(50),
    @PHONE INT,
    @CITY VARCHAR(50),
    @S_GENDER VARCHAR(50),
    @S_FACULTY VARCHAR(50),
    @S_GRADYEAR INT,
    @AGE INT
AS
BEGIN
    BEGIN TRY
        INSERT INTO Students 
        VALUES (@S_FNAME, @S_LNAME, @PHONE, @CITY, @S_GENDER, @S_FACULTY, @S_GRADYEAR, @AGE)
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
------------------------------------------------------------------------------------------------------
-- Update Student Procedure
CREATE OR ALTER PROC UPDATE_STD
    @SID INT,
    @S_FNAME VARCHAR(50),
    @S_LNAME VARCHAR(50),
    @PHONE INT,
    @CITY VARCHAR(50),
    @S_GENDER VARCHAR(50),
    @S_FACULTY VARCHAR(50),
    @S_GRADYEAR INT,
    @AGE INT
AS 
BEGIN
    BEGIN TRY
        UPDATE Students SET
            St_Fname = @S_FNAME,
            St_Lname = @S_LNAME,
            PHONE = @PHONE,
            City = @CITY,
            Gender = @S_GENDER,
            Faculty = @S_FACULTY,
            Grad_Year = @S_GRADYEAR,
            Age = @AGE
        WHERE St_Id = @SID
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
------------------------------------------------------------------------------------
-- Delete Student Procedure
CREATE OR ALTER PROC DELETE_STDS
    @ST_ID INT
AS
BEGIN 
    BEGIN TRY
        DELETE FROM Students WHERE St_Id = @ST_ID
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
