------------------------------------Course SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE select_Course(@Course_Id INT)
AS
	BEGIN
		IF @Course_Id = 0
			BEGiN 
				SELECT * FROM Courses
			END
		ELSE
		SELECT *
		FROM	Courses
		WHERE Course_Id = @Course_Id
	END
----------------------------------------------------------------------------------------
------------------------------------Course UPDATE Proc------------------------------
CREATE PROCEDURE Update_Course
(
    @Course_Id INT,  
    @Course_Name VARCHAR(50),  
    @Course_Duration INT
)                               
AS
BEGIN TRY  
    UPDATE Courses
    SET    
	    Course_Id=@Course_Id,
        Course_Name = @Course_Name,
        Course_Duration = @Course_Duration
    WHERE Course_Id = @Course_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Course INSERT Proc------------------------------
CREATE PROCEDURE Insert_Course
(
    @Course_Id INT,  
    @Course_Name VARCHAR(50),  
    @Course_Duration INT
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Courses
        (
            Course_Id ,  
            Course_Name ,  
            Course_Duration
        )   
        VALUES
        (
            @Course_Id,  
            @Course_Name,  
            @Course_Duration
        );   
    END TRY	
    
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;

----------------------------------------------------------------------------------------
------------------------------------Course Delete Proc-----------------------------
CREATE PROCEDURE Delete_Course
(
    @Course_Id INT
)
AS
BEGIN TRY
    DELETE FROM Courses 
    WHERE Course_Id = @Course_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

