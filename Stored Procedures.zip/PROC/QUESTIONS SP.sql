-- Retrieve Questions Procedure
CREATE PROCEDURE Select_Qestion(@Q_Id Varchar(50))
AS
BEGIN
    -- Select all rows from Questions table
    SELECT * FROM Questions
	Where Quest_Id=@Q_Id
END

-------------------------------------------------------

-- Add Question Procedure
-- Add Question Procedure
CREATE OR ALTER PROCEDURE Insrt_Question
    @Q_Id Varchar(25),
    @Q_TYPE VARCHAR(25),  
    @Q_TITLE VARCHAR(250), 
    @M_ANSWER VARCHAR(250), 
    @Q_LEVEL VARCHAR(50), 
    @C_ID INT 
AS 
BEGIN 
    BEGIN TRY
        -- Insert a new row into Questions table
        INSERT INTO Questions 
            (Quest_Id, Quest_Type, Quest_Title, Model_Answer, Quest_Level, Course_Id) 
        VALUES 
            (@Q_Id, @Q_TYPE, @Q_TITLE, @M_ANSWER, @Q_LEVEL, @C_ID)
    END TRY
    BEGIN CATCH
        -- Return an error message if an error occurs
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END


-------------------------------------------------------

-- Update Question Procedure
CREATE OR ALTER PROCEDURE UPDATE_QUEST
    @Q_ID2 INT, 
    @Q_TYPE2 VARCHAR(25),
    @Q_TITLE2 VARCHAR(250),
    @M_ANSWER2 VARCHAR(250), 
    @Q_LEVEL2 VARCHAR(50), 
    @C_ID2 INT 
AS
BEGIN
    BEGIN TRY
        -- Update the specified row in Questions table
        UPDATE QUESTIONS 
        SET 
            Quest_Type = @Q_TYPE2,
            Quest_Title = @Q_TITLE2,
            Model_Answer = @M_ANSWER2,
            Quest_Level = @Q_LEVEL2,
            Course_Id = @C_ID2
        WHERE 
            Quest_Id = @Q_ID2
    END TRY
    BEGIN CATCH
        -- Return an error message if an error occurs
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END

-------------------------------------------------------

-- Delete Question Procedure
CREATE OR ALTER PROCEDURE DELETE_QUEST
    @Q_ID3 INT -- ID of the question to be deleted
AS
BEGIN 
    BEGIN TRY
        -- Delete the specified row from Questions table
        DELETE FROM Questions WHERE Quest_Id = @Q_ID3
    END TRY
    BEGIN CATCH
        -- Return an error message if an error occurs
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
