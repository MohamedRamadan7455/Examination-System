------------------------------------------Select Topic ------------------------------------------------------
-------------------------------------------------------------------------------------------------------

CREATE PROCEDURE Select_Topic
    @topic_ID INT
AS
BEGIN
    IF @topic_ID = 0
    BEGIN 
        SELECT * FROM Topics
    END
    ELSE
        SELECT * FROM Topics WHERE topic_ID = @topic_ID
END

---------------------------------------Insert Topic-----------------------------
--------------------------------------------------------------------------------
CREATE PROCEDURE Insert_Topic
    @Topic_Id INT,  
    @Topic_Name VARCHAR(50),  
    @Course_ID INT 
AS  
BEGIN TRY 
    INSERT INTO Topics (Topic_ID, Topic_Name, Course_ID)
    VALUES (@Topic_Id, @Topic_Name, @Course_ID)
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors
END CATCH

----------------------------------------------------------------------------------------
------------------------------------------Update---------------------------------------
CREATE PROCEDURE Update_Topic
    @Topic_Id INT,  
    @Topic_Name VARCHAR(50),  
    @Course_ID INT 
AS  
BEGIN TRY
    UPDATE Topics 
    SET Topic_Name = @Topic_Name,
        Course_ID = @Course_ID
    WHERE Topic_ID = @Topic_ID
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors
END CATCH

-------------------------------------- Delete----------------------------------------------------
-------------------------------------------------------------------------------------------------

CREATE PROCEDURE Delete_topic
    @topic_ID INT
AS
BEGIN TRY
    DELETE FROM Topics  
    WHERE topic_ID = @topic_ID
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors
END CATCH
	
