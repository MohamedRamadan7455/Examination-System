------------------------------------Ins_Course SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE  Select_InstCourse(@Instructor_ID   INT)
AS
	BEGIN
		IF @Instructor_ID   = 0
			BEGiN 
				SELECT * FROM Inst_Course
			END
		ELSE
		SELECT *
		FROM Inst_Course
		WHERE Ins_Id  =  @Instructor_ID 
	END
----------------------------------------------------------------------------------------
------------------------------------Ins_Course Delete Proc-----------------------------

CREATE PROCEDURE  Delete_InsCourse(@Instructor_ID  INT)

 AS
	BEGIN TRY
		DELETE FROM Inst_Course  
            WHERE   Ins_ID  = @Instructor_ID  
	END TRY

	BEGIN CATCH
			SELECT ERROR_MESSAGE() as Errors
		
	END CATCH
----------------------------------------------------------------------------------------
------------------------------------Ins_Course  Insert Proc------------------------------
create PROCEDURE  insert_InsCourse(@Instructor_ID  int,  
                                   @Course_ID  varchar(50))
                                          
AS  
	BEGIN  TRY
		INSERT INTO Inst_Course(Ins_Id, 
		                       Course_Id)
						   
					VALUES(@Instructor_ID,  
                           @Course_ID)
	END TRY
	
	BEGIN CATCH
		SELECT ERROR_MESSAGE() as Errors	
	END CATCH
----------------------------------------------------------------------------------------
------------------------------------Ins_Course UPDATE Proc------------------------------

CREATE PROCEDURE  Update_InsCourse  (@Instructor_ID int,  
                                      @Course_ID  varchar(50))                              
AS  
	BEGIN TRY  
		UPDATE Inst_Course 
        SET    Ins_ID = @Instructor_ID,  
			   Course_ID = @Course_ID              			   
        WHERE  Ins_ID = @Instructor_ID
        END TRY

		BEGIN CATCH
			SELECT ERROR_MESSAGE() as Errors
		END CATCH