------------------------------------Instructor SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE select_Ins(@Ins_Id INT)
AS
	BEGIN
		IF @Ins_Id = 0
			BEGiN 
				SELECT * FROM Instructors
			END
		ELSE
		SELECT *
		FROM	Instructors
		WHERE Ins_Id=@Ins_Id
	END
----------------------------------------------------------------------------------------
------------------------------------Instructors UPDATE Proc------------------------------
CREATE PROCEDURE Update_Instructors 
(
    @Ins_Id INT,  
    @F_Name VARCHAR(50),  
    @L_Name VARCHAR(50),
    @Phone VARCHAR(50),
    @City VARCHAR(50),
    @Gender VARCHAR(50),  
    @Hiring_Date DATE,
    @Salary INT,
    @Age INT
)                               
AS  
BEGIN TRY  
    UPDATE Instructors  
    SET   
        Ins_Fname = @F_Name,
        Ins_Lname = @L_Name,
        Phone = @Phone,
        City = @City,
        Gender = @Gender,
        Hiring_Date = @Hiring_Date,
        Salary = @Salary,
        Age = @Age
    WHERE  Ins_Id = @Ins_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
----------------------------------------------------------------------------------------
------------------------------------Instructors INSERT Proc------------------------------
CREATE PROCEDURE Insert_INS 
(
    @Ins_Id INT,  
    @F_Name VARCHAR(50),  
    @L_Name VARCHAR(50),
    @Phone VARCHAR(50),
    @City VARCHAR(50),
    @Gender VARCHAR(50),  
    @Hiring_Date DATE,
    @Salary INT,
    @Age INT
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Instructors
        (
            Ins_Id,  
            Ins_Fname,  
            Ins_Lname,
            Phone,
            City,
            Gender,  
            Hiring_Date,
            Salary,
            Age
        )   
        VALUES
        (
            @Ins_Id,  
            @F_Name,  
            @L_Name,
            @Phone,
            @City,
            @Gender,  
            @Hiring_Date,
            @Salary,
            @Age
        );   
    END TRY	
    
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;
----------------------------------------------------------------------------------------
------------------------------------Instructors Delete Proc-----------------------------
CREATE PROCEDURE Delete_Ins
(
    @Ins_Id INT
)
AS
BEGIN TRY
    DELETE FROM Instructors 
    WHERE Ins_Id = @Ins_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

