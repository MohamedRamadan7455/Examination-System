-- PROCEDURE Student-Answer
-- Insert Student Answer Procedure
CREATE PROCEDURE insert_St_Answer_table
(
    @Date date, 
    @Quest_id INT,
	@Exam_id int,
	@St_id int,
	@Stud_Answer varchar(200),
	@Stud_Grade int
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Student_Answer
        (
            Date,
			Quest_Id,
			Exam_Id,
            St_Id,  
            Stud_Answer,
			Stud_Grade
		)   
        VALUES
        (
            @Date, 
            @Quest_id,
	        @Exam_id,
	        @St_id,
	        @Stud_Answer,
	        @Stud_Grade 
        );   
    END TRY
	
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;
----------------------------------------------------------------
-- Update Student Answer Procedure
CREATE PROCEDURE Delete_St_Answer_table
(
   @Date date,
   @St_Id int,
   @Exam_Id int,
   @Quest_Id int
)
AS
BEGIN TRY
    DELETE FROM Student_Answer
    WHERE 
       St_Id = @St_Id
      AND Exam_Id = @Exam_Id
      AND Quest_Id = @Quest_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;


----------Select Student Answer Procedure--------------------------------------------------------
CREATE PROCEDURE select_StudentAnswer
(
    @St_Id INT,
    @Exam_Id INT,
    @Quest_Id INT
)
AS    
BEGIN 
    SELECT * 
    FROM Student_Answer
    WHERE  
        St_Id = @St_Id
        AND Exam_Id = @Exam_Id
        AND Quest_Id = @Quest_Id;
END;
----------------------------------update------------------------------------
CREATE PROCEDURE update_StudentAnswer
(
    @St_Id INT,
    @Exam_Id INT,
    @Quest_Id INT,
    @New_Stud_Answer VARCHAR(200),
    @New_Stud_Grade INT
)
AS    
BEGIN 
    UPDATE Student_Answer
    SET  
        Stud_Answer = @New_Stud_Answer,
        Stud_Grade = @New_Stud_Grade
    WHERE  
        St_Id = @St_Id
        AND Exam_Id = @Exam_Id
        AND Quest_Id = @Quest_Id;
END;
