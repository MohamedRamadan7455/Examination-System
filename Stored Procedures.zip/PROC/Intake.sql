------------------------------------Intake SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE select_Intake(@Intake_Num INT)
AS
    BEGIN
        IF @Intake_Num = 0
            BEGIN 
                SELECT * FROM Intake
            END
        ELSE
            SELECT *
            FROM Intake
            WHERE Intake_Num = @Intake_Num
    END
------------------------------------------------------------------------------------
------------------------------------Intake UPDATE Proc------------------------------
CREATE PROCEDURE Update_Intake
(
    @Intake_Num INT,  
    @Intake_Start Date,  
    @Intake_End Date
)                               
AS
BEGIN TRY  
    UPDATE Intake
    SET    
	Intake_Num= @Intake_Num,
    Intake_Start = @Intake_Start,  
    Intake_End = @Intake_End
    WHERE Intake_Num = @Intake_Num;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Intake INSERT Proc------------------------------
CREATE PROCEDURE Insert_Intake
(
    @Intake_Num INT,  
    @Intake_Start Date,  
    @Intake_End Date
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Intake
        (
            Intake_Num ,  
            Intake_Start,  
            Intake_End 
        )   
        VALUES
        (
            @Intake_Num ,  
            @Intake_Start ,  
            @Intake_End 
        );   
    END TRY	
    
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;

----------------------------------------------------------------------------------------
------------------------------------Intake Delete Proc-----------------------------
CREATE PROCEDURE Delete_Intake
(
    @Intake_Num INT
)
AS
BEGIN TRY
    DELETE FROM Intake
    WHERE Intake_Num = @Intake_Num;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

