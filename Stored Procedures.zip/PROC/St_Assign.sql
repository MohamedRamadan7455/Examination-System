
-- PROCEDURE Student-Assign
-----------------------------------------------------------------------------------------------------------------------
Create PROCEDURE Insert_StudentAssign
(
    @Date date, 
    @St_id INT,
	@track_id int,
	@Branch_id int
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Student_Assign
        (
            Date,  
            St_Id,  
            track_id,
			Branch_id
        )   
        VALUES
        (
           @Date, 
           @St_id ,
	       @track_id ,
	       @Branch_id

        );   
    END TRY
	
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;
--------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE Update_StudentAssign
(
    @Date date, 
    @St_id INT,
    @track_id int,
    @Branch_id int
)                               
AS
BEGIN TRY  
    UPDATE Student_Assign
    SET    
        St_Id = @St_id,
        track_id = @track_id,
        Branch_id = @Branch_id
    WHERE 
        St_Id = @St_id AND
        track_id = @track_id AND
        Branch_id = @Branch_id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE Delete_StudentAssign
(
   @St_Id INT,
   @track_id INT,
   @Branch_id INT
)
AS
BEGIN TRY
    DELETE FROM Student_Assign
    WHERE St_Id = @St_Id AND
        track_id = @track_id AND
        Branch_id = @Branch_id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

-----------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE select_StudentAssign
(
    @Date date,
    @St_Id INT,
    @track_id INT,
    @Branch_id INT
)
AS    
BEGIN 
    IF @Date IS NOT NULL
    BEGIN 
        SELECT * FROM Student_Assign
    END
    ELSE
    BEGIN
        SELECT *
        FROM Student_Assign
        WHERE St_Id = @St_Id 
        AND track_id = @track_id 
        AND Branch_id = @Branch_id;
    END
END;
