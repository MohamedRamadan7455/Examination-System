------------------------------------Instructor_Track SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE Select_Instructor_Track
    @Track_Id INT = 0,
    @Instructor_Id INT = 0
AS
BEGIN
    IF @Track_Id = 0 AND @Instructor_Id = 0
    BEGIN
        SELECT * FROM Tracks;
    END
    ELSE
    BEGIN
        SELECT * FROM Tracks_Instructors WHERE Track_Id = @Track_Id AND Ins_Id = @Instructor_Id;
    END
END
----------------------------------------------------------------------------------------
------------------------------------Instructor_Track Delete Proc-----------------------------

CREATE PROCEDURE Delete_TrackIns
    @Track_Id INT,
    @Instructor_Id INT
AS
BEGIN TRY
    DELETE FROM Tracks_Instructors
    WHERE Track_Id = @Track_Id AND Ins_Id = @Instructor_Id;
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Instructor_Track Insert Proc------------------------------
CREATE PROCEDURE Insert_TrackIns
    @Track_Id INT,
    @Instructor_Id INT
AS
BEGIN TRY
    INSERT INTO Tracks_Instructors(Track_Id, Ins_Id)
    VALUES (@Track_Id, @Instructor_Id);
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Instructor_Track UPDATE Proc------------------------------

Create PROCEDURE Update_Instructor_Track
    @Track_Id INT,
    @Instructor_Id INT
AS
BEGIN TRY
    UPDATE Tracks_Instructors
    SET Track_Id = @Track_Id,
	Ins_Id = @Instructor_Id
    WHERE Ins_Id = @Instructor_Id;
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;
		