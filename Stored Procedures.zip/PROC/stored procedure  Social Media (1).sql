
-------stored procedure  Social Media

CREATE PROCEDURE Delete_SocialMedia
(
   @Social_Link varchar(250)
)
AS
BEGIN TRY
    DELETE FROM Social_Media
    WHERE Social_Link= @Social_Link;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
GO


---------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE select_SocialMedia(@Social_Link varchar(250))
AS
	BEGIN
		IF @Social_Link = 0
			BEGiN 
				SELECT * FROM Social_Media
			END
		ELSE
		SELECT *
		FROM	Social_Media
		WHERE Social_Link = @Social_Link
	END


	---------------------------------------------------------------------------------------------------------------------------------------------
	CREATE PROCEDURE SocialMedia
(
    @Social_Link varchar(250), 
    @St_id INT,
	@Social_Name varchar(75),
	@Photo varbinary(max)
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Social_Media
        (
            Social_Link,  
            St_Id,  
            Social_Name,
			Photo
        )   
        VALUES
        (
           @Social_Link,  
           @St_id,  
            @Social_Name,
			@Photo

        );   
    END TRY
	
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;

---------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE Update_SocialMedia
(
     @Social_Link varchar(250), 
    @St_id INT,
	@Social_Name varchar(75),
	@Photo varbinary(max)
)                               
AS
BEGIN TRY  
    UPDATE Social_Media
    SET    
		    St_Id=@St_id,
            Social_Name=@Social_Name,
			Photo = @Photo
    WHERE Social_Link =@Social_Link;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH