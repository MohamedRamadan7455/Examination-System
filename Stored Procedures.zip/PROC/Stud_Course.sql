-------------------------------Select Student_Course-------------------
------------------------------------------------------------------------
CREATE PROCEDURE Select_StudentCourse
    @Stud_ID INT
AS
BEGIN
    IF @Stud_ID = 0
    BEGIN 
        SELECT * FROM Student_Course;
    END
    ELSE
    BEGIN
        SELECT * FROM Student_Course WHERE St_Id = @Stud_ID;
    END
END

----------------------------------Delete Student_Course-------------------
--------------------------------------------------------------------------

CREATE PROCEDURE Delete_StudentCourse
    @Stud_ID INT
AS
BEGIN TRY
    DELETE FROM Student_Course  
    WHERE St_ID = @Stud_ID;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;
---------------------------------------------------------------------------=
-------------------------------Insert Student_Course------------------------
CREATE PROCEDURE insert_StudentCourse 
    @Stud_ID INT,  
    @Course_ID INT
AS  
BEGIN TRY
    INSERT INTO Student_Course (St_ID, Course_ID)
    VALUES (@Stud_ID, @Course_ID);
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

--------------------------------------------------------------------------------
-------------------------------Update Student_Course----------------------------
CREATE PROCEDURE Update_StudentCourse    
    @Stud_ID INT,  
    @Course_ID INT
AS  
BEGIN TRY  
    UPDATE Student_Course 
    SET St_ID = @Stud_ID,  
        Course_ID = @Course_ID
    WHERE St_ID = @Stud_ID;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;
