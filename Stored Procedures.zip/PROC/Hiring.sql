------------------------------------Hiring SELECT Proc------------------------------
----------------------------------------------------------------------------------------
CREATE PROCEDURE select_Hiring(@Hiring_Id INT)
AS
	BEGIN
		IF @Hiring_Id= 0
			BEGiN 
				SELECT * FROM Hiring
			END
		ELSE
		SELECT *
		FROM	Hiring
		WHERE Hiring_Id = @Hiring_Id
	END
----------------------------------------------------------------------------------------
------------------------------------Hiring UPDATE Proc------------------------------
CREATE PROCEDURE Update_Hiring
(
    @Hiring_Id INT,  
    @St_Id INT,
	@Job_Title Varchar(75),
    @Hiring_Date Date,
	@Company_Name Varchar(75)
)                               
AS
BEGIN TRY  
    UPDATE Hiring
    SET
	St_Id=@Hiring_Id,
    St_Id=@St_Id,
	Job_Title = @Job_Title,
    Hiring_Date = @Hiring_Date,
	Company_Name = @Company_Name
	Where Hiring_Id=@Hiring_Id
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

----------------------------------------------------------------------------------------
------------------------------------Hiring INSERT Proc------------------------------
CREATE PROCEDURE Insert_Hiring
(
    @Hiring_Id INT,  
    @St_Id INT,
	@Job_Title Varchar(75),
    @Hiring_Date Date,
	@Company_Name Varchar(75)
)   
AS  
BEGIN  
    BEGIN TRY
        INSERT INTO Hiring
        (
    Hiring_Id,  
    St_Id,
	Job_Title,
    Hiring_Date,
	Company_Name 
        )   
        VALUES
        (
    @Hiring_Id ,  
    @St_Id ,
	@Job_Title,
    @Hiring_Date,
	@Company_Name 
	     )
    END TRY	
    
    BEGIN CATCH
        SELECT ERROR_MESSAGE() as Errors;	
    END CATCH;
END;

----------------------------------------------------------------------------------------
------------------------------------Hiring Delete Proc-----------------------------
CREATE PROCEDURE Delete_Hiring
(
    @Hiring_Id INT
)
AS
BEGIN TRY
    DELETE FROM Hiring
	WHERE Hiring_Id = @Hiring_Id;
END TRY

BEGIN CATCH
    SELECT ERROR_MESSAGE() as Errors;
END CATCH;

