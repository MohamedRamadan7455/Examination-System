-- Procedure to retrieve all freelance records
CREATE OR ALTER PROC Select_FreeLance(@FreeLance_Id INT)
AS 
BEGIN
    SELECT * FROM Freelance
    WHERE Freelance_Id = @FreeLance_Id
END

------------------------

-- Procedure to add a new freelance record
CREATE OR ALTER PROC Insert_Freelance
    @S_ID INT,
    @Job_Title VARCHAR(75),
    @PLatform VARCHAR(75),
    @Start_Date DATE,
    @End_Date DATE,
    @COST MONEY
AS
BEGIN
    BEGIN TRY
        INSERT INTO Freelance 
            VALUES(@S_ID, @Job_Title, @PLatform, @Start_Date, @End_Date, @COST)
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END

-------------------------

-- Procedure to update an existing freelance record
CREATE OR ALTER PROCEDURE Update_FreeLance
    @F_ID INT,
    @S_ID INT,
    @J_TITLE VARCHAR(75),
    @PLATFORM VARCHAR(75),
    @S_DATE DATE,
    @E_DATE DATE,
    @COST MONEY
AS 
BEGIN
    BEGIN TRY
        UPDATE Freelance 
        SET
            St_Id = @S_ID,
            Job_Title = @J_TITLE,
            Platform = @PLATFORM,
            Start_Date = @S_DATE,
            End_Date = @E_DATE,
            Cost = @COST
        WHERE Freelance_Id = @F_ID
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END

---------------------------------------------------------------------

-- Procedure to delete a freelance record by ID
CREATE OR ALTER PROC Delete_FreeLance
    @FID INT
AS
BEGIN 
    BEGIN TRY
        DELETE FROM Freelance WHERE Freelance_Id = @FID
    END TRY
    BEGIN CATCH
        SELECT 'ERROR' AS ErrorMessage
    END CATCH
END
