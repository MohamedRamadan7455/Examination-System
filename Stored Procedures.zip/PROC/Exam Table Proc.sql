----------------------------------------------Exam Table----------------------------
----------------------------------------------PROC INSERT---------------------------
CREATE PROCEDURE insertExam 
(
    @Exam_ID int,
    @Duration INT,
    @Exam_FullMark Int,
    @Question_Num INT,
    @Cr_id int
)
AS
BEGIN TRY
    INSERT INTO Exams (Exam_ID, Exam_Duration, Exam_FullMark, Question_Num, Course_Id)
    VALUES (@Exam_ID, @Duration, @Exam_FullMark, @Question_Num, @Cr_id)
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

------------------------------------------------SELECT PROC-------------------------------------
--------------------------------------------------------------------------------------------
CREATE PROCEDURE selectexam 
    @Exam_ID int
AS 
BEGIN TRY
    SELECT * FROM Exams
    WHERE Exam_Id = @Exam_ID
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;

 ----------------------------------- UPDATE PROC----------------------------------------------
 --------------------------------------------------------------------------------------------
CREATE PROCEDURE updateExam 
    @Exam_ID int,
    @Duration INT,
    @Exam_FullMark Int,
    @Question_Num INT,
    @Cr_id int
AS 
BEGIN TRY
    UPDATE Exams
    SET
        Exam_Duration = @Duration,
        Exam_FullMark = @Exam_FullMark,
        Question_Num = @Question_Num,
        Course_Id = @Cr_id
    WHERE Exam_Id = @Exam_ID
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;
 
 ----------------------------------- ---- PROCE DELETE ------------------------------------------------
-------------------------------------------------------------------------------------------------------
CREATE PROCEDURE deleteExam 
    @Exam_ID int
AS 
BEGIN TRY
    DELETE FROM Exams
    WHERE Exam_Id = @Exam_ID
END TRY
BEGIN CATCH
    SELECT ERROR_MESSAGE() AS Errors;
END CATCH;
